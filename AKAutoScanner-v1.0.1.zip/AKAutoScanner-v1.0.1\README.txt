AK Auto-Scanner v1.0.1
========================================

Quick Start:
1. Run AKAutoScanner\AKAutoScanner.exe
2. Open Kindle for PC and navigate to first page
3. Configure settings in the application
4. Click "Start Scanning"
5. Wait 5 seconds for countdown
6. Scanning will begin automatically

Output: output\kindle_scan_YYYYMMDD_HHMMSS.pdf

For detailed instructions, see START_HERE.md

Press ESC at any time to stop scanning.

What's New in v1.0.1:
- Fixed premature scan termination (now supports up to 10,000 pages)
- Improved scan reliability with better duplicate detection
- Added retry logic for page turning
